import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeMainComponent } from './views/home-main/home-main.component';
import { LeafletMapComponent } from './views/home-main/leaflet-map/leaflet-map.component';
import { ReservationComponent } from './views/home-main/reservation/reservation.component';
import { SingleStationComponent } from './views/home-main/single-station/single-station.component';
import { StationHomeComponent } from './views/home-main/station-home/station-home.component';
import { StationListComponent } from './views/home-main/station-list/station-list.component';
import { StationComponent } from './views/home-main/station/station.component';

const routes: Routes = [
  { path : 'station/:number', component: SingleStationComponent},
  { path : 'carte/:number' , component: LeafletMapComponent},
  { path : 'carte' , component: LeafletMapComponent},
  { path : 'reservation/:number' , component: ReservationComponent},
  { path : 'station' , component : StationHomeComponent },
  { path : '' , component : HomeMainComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
