import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { map, Observable } from "rxjs";
import { BddJcDecaux } from "./modele.model";
import * as L from 'leaflet';

@Injectable({
    providedIn: 'root'
})
export class ServiceJcDecaux {

    //on appelle la requete http
    constructor(private http : HttpClient) {}

    keyApi : string = '6353af73c5b98a97dc554eb49890bbbbcc0cd41d';

    // on creer la function qui appelle jCDecaux
    getAllJcdecaux() : Observable<BddJcDecaux[]> {
        const test = this.http.get<BddJcDecaux[]>('https://api.jcdecaux.com/vls/v1/stations?contract=Lyon&apiKey=' + this.keyApi);
        return test;
    }

    //on creer la function qui appelle une seule station
    getAloneStation( aloneStation : number ) : Observable<BddJcDecaux>{
        //console.log(aloneStation);
        const result = this.http.get<BddJcDecaux>(`https://api.jcdecaux.com/vls/v3/stations/${aloneStation}?contract=Lyon&apiKey=6353af73c5b98a97dc554eb49890bbbbcc0cd41d`);
        //console.log(result);
        return result;
    }
}

// définition des option visuelles des markers leaflet
const iconRetinaUrl = 'assets/Map-Marker-Transparent-Image.png';
const iconUrl = 'assets/Map-Marker-Transparent-Image.png';
const shadowUrl = 'assets/';
const iconDefault = L.icon({iconRetinaUrl, iconUrl, shadowUrl});
L.Marker.prototype.options.icon = iconDefault;

@Injectable({
    providedIn: 'root'
})
export class MarkerService{

  placeMarker(map : L.Map, x : number, y : number, name : string) {
      const marker = L.marker([x,y]);

      const popupContent : string = "<div class='popupContent'>"+ name +"</div>";
      marker.bindPopup(popupContent);

      marker.addTo(map)
  }

}