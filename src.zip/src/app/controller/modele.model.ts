export class home {
    title !: string;
    subTitleLeft !: string;
    subTitleRight !: string;
}
export class BddJcDecauxStationAlone {
    //id !: number[];
    number !: number;
    contractName !: string;
    name !: string;
    address !: string;
    position !: {
        latitude: number;
        longitude : number;
    } ;
    banking !: string;
    lastUpdate !: Date;
    available_bikes !: number;
    status !: string;
    lat !: string;
    lng !: string;
    
}

export class BddJcDecaux {
    //id !: number[];
    number !: number;
    contract_name !: string;
    name !: string;
    address !: string;
    position !: {
        lat: number;
        lng : number;
    } ;
    banking !: string;
    lastUpdate !: Date;
    available_bikes !: number;
    status !: string;
}

export class FormulaireReservation{
    nom !: string ;
    prenom !: string ;
    email !: string ;
    date !: Date ;
    cgv !: undefined ;
}