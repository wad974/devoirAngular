import { NgModule } from '@angular/core';
import{ HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './views/header/header.component';
import { HomeMainComponent } from './views/home-main/home-main.component';
import { FooterComponent } from './views/footer/footer.component';
import { StationComponent } from './views/home-main/station/station.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LeafletMapComponent } from './views/home-main/leaflet-map/leaflet-map.component';
import { ReservationComponent } from './views/home-main/reservation/reservation.component';
import { StationListComponent } from './views/home-main/station-list/station-list.component';
import { StationHomeComponent } from './views/home-main/station-home/station-home.component';
import { SingleStationComponent } from './views/home-main/single-station/single-station.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeMainComponent,
    FooterComponent,
    StationComponent,
    LeafletMapComponent,
    ReservationComponent,
    StationListComponent,
    StationHomeComponent,
    SingleStationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
