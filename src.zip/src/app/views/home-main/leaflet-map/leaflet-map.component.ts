
import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as L from 'leaflet';
import { Map } from 'leaflet';
import { Observable } from 'rxjs';
import { BddJcDecaux } from 'src/app/controller/modele.model';
import { ServiceJcDecaux, MarkerService } from 'src/app/controller/service.service';

@Component({
  selector: 'app-leaflet-map',
  templateUrl: './leaflet-map.component.html',
  styleUrls: ['./leaflet-map.component.scss']
})

export class LeafletMapComponent implements AfterViewInit, OnInit {
  //variable 
 @Input() station !: BddJcDecaux;
  numberStation !: number;
  
 
  //on recupere makerservice
    constructor( 
      private markerService : MarkerService,
      private serviceStation : ServiceJcDecaux,
      private route: ActivatedRoute,
      private router : Router
       ){}

  tableau$ : Observable<BddJcDecaux[]> | null = null;
    
  // on declare les var
  private map !: Map ;

    
  ngOnInit(){
    const numberStation = +this.route.snapshot.params['number'];
    this.numberStation = numberStation;
    //var recup = "";
    
  }

  // bouton reserver
viewReservation(){
  this.router.navigateByUrl(`reservation`);
}

  ngAfterViewInit(){
    // si pas de number affiche toutes les marker
      // LYON
      let x : number = 45.7603831; //latitude
      let y : number = 4.849664; // longitude
      let z : number = 10;

      this.map = L.map('map', {
        center: [ x, y],
        zoom: z
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      }).addTo(this.map);

      
    // conditions 
    if( this.numberStation )
    {
        //code si number est dans le GET
        //affiche marker number
        this.tableau$ = this.serviceStation.getAllJcdecaux();
        this.tableau$.subscribe(
          data => {
            for( let value of data )
            {
              if(value.number === this.numberStation)
              {
                var position = value.position;
              
                const lat = position.lat;
                const lng = position.lng;
                
                //on affiche tous les marker
                this.markerService.placeMarker(this.map, lat, lng, '<div class="serviceStation"> <h3>Stations-'+value.contract_name+'</h3> <p><strong>nom:</strong> '+value.name+'</p> <p> <strong>adresse:</strong> '+value.address+'</p><p> <strong>Vélos disponible: '+value.available_bikes+'</strong> </p><a href="reservation/'+value.number+'" >Reservation</a></div>');
                }
            }
          }
        );

    } else 
    {
      // on recupere les données de l'observable et on ajoute un marquer pour chaque élement
      this.tableau$ = this.serviceStation.getAllJcdecaux();
      this.tableau$.subscribe(
        donnees => {
          for( let value of donnees ){
            
              var data = value.position;
              
              const lat = data.lat;
              const lng = data.lng;
              
              //on affiche tous les marker
              this.markerService.placeMarker(this.map, lat, lng, '<div class="serviceStation"> <h3>Stations-'+value.contract_name+'</h3> <p><strong>nom:</strong> '+value.name+'</p> <p> <strong>adresse:</strong> '+value.address+'</p><p> <strong>Vélos disponible: '+value.available_bikes+'</strong> </p><a href="reservation/'+value.number+'" >Reservation</a></div>');
            }
          }
        
      );
    }
    
    
  }

}

