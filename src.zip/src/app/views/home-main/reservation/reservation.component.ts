import { Component, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, map, Subject, BehaviorSubject, ReplaySubject, AsyncSubject, tap, filter } from 'rxjs';
import { BddJcDecaux, BddJcDecauxStationAlone, FormulaireReservation } from 'src/app/controller/modele.model';
import { ServiceJcDecaux } from 'src/app/controller/service.service';

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.scss']
})
export class ReservationComponent {
  //variable
 @Input() station !: BddJcDecauxStationAlone;
  station$ !: Observable<BddJcDecaux>;
  reservation !: FormGroup;
  reservationPreview$ !: Observable<FormulaireReservation>;
  urlValid !: RegExp;
  buttonLog !: string;
  buttonSnap !: string;

  //form
  counter !: Observable<number>;
  private subject !: AsyncSubject<number>;
  private count !: number

  nom !: string;
  prenom !: string;
  email !: string;
  date !: string;
  cgv !: string;

   //on appel le constructeur formulaire et le service JcDECAUX + service Route
  constructor( 
    private formBuilder : FormBuilder,
    private serviceStation : ServiceJcDecaux,
    private route : ActivatedRoute,
    private router : Router,
    ){}
  
  // ngOnInit
  ngOnInit(): void {
    //buttonSnap
    this.buttonSnap = 'Retour';
    //buttonEnregistre
    this.buttonLog = 'Enregistrer';

    //on recupere le number dans la method GET
    const numberStation = this.route.snapshot.params['number'];
    //on recupere la station via le number
    this.station$ = this.serviceStation.getAloneStation(numberStation);

    //Formulaire
    //on verifie l'url
    this.urlValid = /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&/=]*)/;

    // on construit ici le formulaire
    this.reservation = this.formBuilder.group(
      {
        nom:[null, [Validators.required]],
        prenom: [null, [Validators.required]],
        email: [null, [Validators.required, Validators.email]],
        date: [null, [Validators.required]],
        cgv: [null, [Validators.required]],
        //imageUrl: [null, [Validators.required, Validators.pattern(this.urlValid)]],
        //location: [null]
      }, {
        updateOn : 'blur'
      }
    );

    
    //console.log(this.reservation)
    //on recupere les valeur sauvegarder dans le navigateur
    // si le formulaire est valide
    /*******PARTIE FORMULAIRE */
    
 
    //preview formulaire lors de l'insertion
    this.reservationPreview$ = this.reservation.valueChanges.pipe(
      //on copie colle le formulaire pour du previews
      map(formValue => ({
        ...formValue,
        createDate: new Date(),
        snap: 0,
        id: 0
      }))
    );
  }


  //function submit
  onSubmitFormReservation(){
    if(this.reservation.valid)
    {
      //console.log(this.reservation)
      //form
     //ici le code
      this.nom = this.reservation.value.nom;
      this.prenom = this.reservation.value.prenom;
      this.prenom = this.reservation.value.prenom;
      this.email = this.reservation.value.email;
      this.date = this.reservation.value.date;

      if(this.reservation.value.cgv)
      {
        this.cgv = 'La CGV à était accepter!'
      }
    }
  }


  onSnap(){
       if(this.buttonLog === 'Enregistrer')
      {
        this.buttonLog = 'GOOD! C\'est Reserver!';
      } else {
        this.buttonLog = 'Enregistrer';
      }

  }
  //onRetour
  onRetour(){
    this.router.navigateByUrl(`/station`);
  }

  //bouton Carte
  viewCarte(){
    //on recuper la route -> number dans get
    const numberStation = +this.route.snapshot.params['number'];
    //on injecte dans la route
    this.router.navigateByUrl(`carte/${numberStation}`);
  }

}
