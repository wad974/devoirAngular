import { Component, Input, OnInit } from '@angular/core';
import { map, Observable } from 'rxjs';
import { BddJcDecaux } from 'src/app/controller/modele.model';
import { ServiceJcDecaux } from 'src/app/controller/service.service';

@Component({
  selector: 'app-station-list',
  templateUrl: './station-list.component.html',
  styleUrls: ['./station-list.component.scss']
})
export class StationListComponent implements OnInit{
  //on creer les variables stations$
  @Input() allStations$ !: Observable<BddJcDecaux[]>; 
 // @Input() Stations$ !: Observable<BddJcDecaux>; 

  //on appelle les services avec le constructor
  constructor(
    private serviceStations : ServiceJcDecaux
  ){}

  ngOnInit(): void {
    //this.allStations$ = this.serviceStations.getAllJcdecaux();
    this.allStations$ = this.serviceStations.getAllJcdecaux()
    .pipe(
      map( BddJcDecaux => {
          return BddJcDecaux.slice(0, 42);
      })
    )
  }


}
