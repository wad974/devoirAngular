import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { map, Observable, tap } from 'rxjs';
import { BddJcDecaux, FormulaireReservation } from 'src/app/controller/modele.model';
import { ServiceJcDecaux } from 'src/app/controller/service.service';

@Component({
  selector: 'app-station',
  templateUrl: './station.component.html',
  styleUrls: ['./station.component.scss']
})
export class StationComponent implements OnInit {

  //@Input() station$ !:  Observable<ApiJcDecaux[]>;
  @Input() station !: BddJcDecaux;
  buttonView !: string;
  buttonSnap !: string;

  constructor(
    public serviceStations : ServiceJcDecaux,
    private router: Router
    ){}



  ngOnInit(){
    //buttonSnap
    this.buttonSnap = 'Like';

    //on recupere les articles

    /*this.station$ = this.ApiStation.getAllJcdecaux()
    .pipe(
      map(ApiJcDecaux => {
          return ApiJcDecaux.slice(0, 2);
      })
    )/**/ 
  }

  //bouton Carte
  viewCarte(){
    this.router.navigateByUrl(`station/carte`)
  }

   //bouton single-station
   viewSingleStation(){
    this.router.navigateByUrl(`station/${this.station.number}`);
   }

}
