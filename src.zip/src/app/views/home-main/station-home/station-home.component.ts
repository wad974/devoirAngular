import { Component } from '@angular/core';

@Component({
  selector: 'app-station-home',
  templateUrl: './station-home.component.html',
  styleUrls: ['./station-home.component.scss']
})
export class StationHomeComponent {

}
