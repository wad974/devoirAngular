import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BddJcDecaux } from 'src/app/controller/modele.model';
import { ServiceJcDecaux } from 'src/app/controller/service.service';

@Component({
  selector: 'app-single-station',
  templateUrl: './single-station.component.html',
  styleUrls: ['./single-station.component.scss']
})
export class SingleStationComponent implements OnInit {
  // on declare la variable stations
  @Input() singleStation !: BddJcDecaux;
  singleStation$ !: Observable<BddJcDecaux>;
  buttonSnap !: string;
  
  //le constructeur pour recupere la base de données
  constructor(
    private serviceStation : ServiceJcDecaux,
    private route: ActivatedRoute,
    private router: Router
  ){}

  ngOnInit(): void {

    //buttonSnap
    this.buttonSnap = 'Retour';

    //on recuper la route -> number dans get
    const numberStation = +this.route.snapshot.params['number'];

    //on injecte dans la function pour recupere une seule station
    this.singleStation$ = this.serviceStation.getAloneStation(numberStation);
  }

  //onRetour
  onRetour(){
    this.router.navigateByUrl(`/station`);
  }

  //bouton Carte
  viewCarte(){
    //on recuper la route -> number dans get
    const numberStation = +this.route.snapshot.params['number'];
    //on injecte dans la route
    this.router.navigateByUrl(`carte/${numberStation}`);
  }

  //bouton Reservation
  onViewReservation(){
    //on recuper la route -> number dans get
    const numberStation = +this.route.snapshot.params['number'];
    //on injecte dans la route
    this.router.navigateByUrl(`reservation/${numberStation}`);
  }
}
